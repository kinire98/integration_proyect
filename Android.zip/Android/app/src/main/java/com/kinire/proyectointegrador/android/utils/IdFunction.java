package com.kinire.proyectointegrador.android.utils;

@FunctionalInterface
public interface IdFunction {
    void apply(long id);
}
